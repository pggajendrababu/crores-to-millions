# Using Curly braces  
print("{} and {} both are the best friend".format("Devansh","Abhishek"))  
  
#Positional Argument  
print("{1} and {0} best players ".format("Virat","Rohit"))  
  
#Keyword Argument  
print("{a},{b},{c}".format(a = "James", b = "Peter", c = "Ricky"))
print("-" * 30)
#-----------------------------------------------------------------------------------------------
# formatted   string
weight = 45
print(f"you are {weight} kilos")
print("-" * 30)
#-----------------------------------------------------------------------------------------------
# percentage operator
x = 5
y = 10.54677
z = 'gajendrababu'
print("x is %d\ny is %0.2f\nz is %s" %(x, y, z))    
print("-" * 30)
#----------------------------------------------------------------------------------------------