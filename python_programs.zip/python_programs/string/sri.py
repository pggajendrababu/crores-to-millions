# ஸ் + ரீ will give us ஸ்ரீ


# note1
# you can only concatenate string with a string.  That is why we have used + symbol 
#  in the print statement note1. If we have to give one string and one variable 
# inside the print statement, then we should separate them using comma.

print (chr(3000) + chr (3021) + chr(2992) + chr(3008)  +  "\n ") # note1
print("babu")

