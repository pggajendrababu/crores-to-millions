def to_list(number) :
    string = str(number) # converts number to string
    length = len(string)
    list = [ ]
    for x in range(length) :
        character = string[x]
        list.append(character)
    return list
    

#print(to_list(7876678.346779))        