for i in range (2944, 3073, 1) :
    print (i,  "  =    ",  chr(i))