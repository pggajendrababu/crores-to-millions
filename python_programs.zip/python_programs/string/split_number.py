def split_number(number) :
    list = [ ]
    
    string = str(number)
    separated_list = string.split('.')
    #print('separated_list = ', separated_list)
    whole_part = separated_list[0]
    fractional_part_with_dot = '.' + separated_list[1]
    
    list.append(whole_part)
    list.append(fractional_part_with_dot)
    return list
    
#print(split_number(2748.998772))