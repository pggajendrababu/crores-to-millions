print('*' * 30)
print( ) # will print empty line
print("\n") # will print empty line (\n = new line)
print("") # will print empty line. (pair of single or double quotes) empty string.

str  = "Python's syntax is simple"

print(str)
print('str[0] = ', str[0])
print('str[1] = ', str[1])
print('str[2] = ', str[2])
print('str[-1] = ', str[-1]) # negative index
print('str[-2] = ', str[-2])
print('*' * 30)

# substring (colon notation)
print('str[0:5] = ', str[0:5]) # starting from 0, excluding  index 5
print('str[4:9] = ', str[4:9]) # starting from 4, excluding  index 9
print('str[1:-2] = ', str[1 : -2]) # starting from 1, excluding  index -2
print('-' * 30)

print('str[0 : ] = ', str[0 : ]) # starting from 0, upto final letter
print('str[ : 5] = ', str[ : 5]) # starting from 0, excluding  index 5
print('str[ : ] = ', str[ : ]) # all letters
print('-' * 30)
