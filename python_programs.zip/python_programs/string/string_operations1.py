str  = "python's syntax is simple"
text = "PYTHON'S SYNTAX IS SIMPLE"

print(len(str))
print('-' * 30)

print(str.capitalize( ))
print(str.upper( ))
print(text.casefold( ))
print(text.lower( ))
print('-' * 30)

print(str.find('thon')) # case sensitive
print('thon' in str) # case sensitive
print(str.replace('s', 'k')) # case sensitive
print(str.replace( 'syntax', 'design')) # case sensitive
print(str.startswith('pyt'))
print(str.endswith('mple'))

babu = "                         India will go to mars  "
print(babu.center(2))

camel = '               Americans_are_honest_and_just_people.      '
print(camel.strip( ))
print(camel.split('_')) # it will return a list

