def cat(str, number) :
    a = "" # empty string (pair of double quotes or single quotes)
    for x in range(number) :
        a = a + str # concatenation
    return a
         
print(cat('=', 30)) 
# second way
print('=' * 30)