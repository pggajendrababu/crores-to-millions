import to_list 
import split_number

def to_indian_format(number) :
    given_list = split_number.split_number(abs(float(number)))
    #print('given_list = ', given_list)
    list = to_list.to_list(given_list[0])
    #print('list = ', list)
    front_list = list [ : -3]
    back_list = list [ -3 :  ]   
    
    a = "" #    empty string
    for item in back_list :
        a = a + item
   
    #print('front_list = ', front_list)
    #print('back_list = ', back_list)
    
    if (len(front_list) % 2 > 0) :  # i.e length of front_list = odd number
        b = front_list[0] + "_"
        c = ""  #    empty string
        for x in range(1, len(front_list), 2) :
            c = c + front_list[x] + front_list[x+1] + "_"
        d = b + c
        #print('d = ', d)
        if number < 0 :
             result = '-' + d + a + given_list[1]
        else :
             result = d + a + given_list[1]
             
    else :
        c = ""  #    empty string
        for x in range(0, len(front_list), 2) :
            c = c + front_list[x] + front_list[x+1] + "_" 
        if number < 0 :
            result = '-' + c + a + given_list[1]
        else :
            result = c + a + given_list[1]                           
    return result


#number =  456588876564.7655
#print(number)             
#print(to_indian_format(number))                                  