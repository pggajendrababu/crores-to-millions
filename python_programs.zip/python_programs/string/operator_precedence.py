# operator' precedence (PEMA)
# 1. parenthesis
# 2. exponentiation (x ** y) (i.e power)
# 3. multiplication or division
# 4. addition or subtraction
 
x = 5 + 4 * 2
print("x = ", x)

y = (5 + 4) * 2
print('y = ', y)

z = 6 / 2 ** 3
print('z = ', z)

# but always use parenthesis wherever necessary.