def square(x) :
    print(x * x) # note1
    
print(square(4))   # note2 

# note1 will print 16.
# by default, in python, all fuctuons return a value.
# If we don't give a return statement in a function, then
# that fuction will return "None" as a value. so note2
# will print object "None"