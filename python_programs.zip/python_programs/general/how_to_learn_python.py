"""-------------------------------------------------------------------------------------------------------------------------------------
how to learn python?
-------------------------------------
=> youtube
=> zip  files
=> web pages (javatpoint, geeksforgeeks, beginnersbook)
=> free downloadable pdf books or epub books
=> wikipedia 
=> github.com
=> apps from "google play store"
=> printed books
=> online compilers (freecodecamp, codecademy)

=> google : python 3 math module
=> interpreter, google : math.ceil in python
=> IDE (pycharm, ecilipse and pydev, spider, rodeo, jupyter), google : string.upper in python
=> python documentation
-------------------------------------------------------------------------------------------------------------------------------------"""
