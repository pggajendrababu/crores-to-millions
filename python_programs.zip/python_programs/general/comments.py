# single line comment

# This is
# multiline
# comment

"""
Docstring is written inside pair of triple quotes. Interpreter will not read comments. whereas interpreter will read the docstring and if write it below a code block or if write it separately, interpreter will print in the output.
"""
print ("Hello World")