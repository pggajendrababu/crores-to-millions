# bool ( ) does not convert string to boolean. bool( ) behaves differently 
# in different circumstances.

#  If a list contains even one element (even it may be element 0), 
# then it returns True.
# If a list contains no elements, then bool( ) returns False.

a = [0]
print ('bool(a) =', bool(a))
b = [1, 2]
print ('bool(b) =', bool(b))
c = [ ]
print ('bool(c) =', bool(c))
print('-' * 30)

# If the value of a variable is greater than 0, then bool( ) returns True.
# If the value of a variable is  0, then bool( ) returns False.

d = 5
print ('bool(d) =', bool(d))
e = 0.0
print ('bool(e) =', bool(e))
print('-' * 30)

# If the value of a variable is a string, then bool( ) returns True.
# If the value of a variable is  None,  then bool( ) returns False.

f = 'India'
print ('bool(f) =', bool(f))
g = None
print ('bool(g) =', bool(g))
print('-' * 30)

# In a input( ) statement, if an user enter some value
# (even it may be False. In that case, "False" is just a string and not a boolean value.
#   remember, input( ) takes only string as a value), then bool( ) returns True.
# In a input( ) statement, if an user enter nothing, 
# then (the value becomes None. so) bool( ) returns False.
case1 = bool(input('enter False : ' ))
case2 = bool(input('enter some string : '))
case3 = bool(input('enter nothing. just press enter.'))
print('case1 = ', case1)
print('case2 = ', case2)
print('case3 = ', case3)
print('-' * 30)

# If the value of a variable is True, bool( ) returns True.
# If the value of a variable is False, bool( ) returns True.
h = True
i = False
print('bool(h) = : ', bool(h))
print('bool(i) = : ', bool(i))
print('-' * 30)

# If a result of an expression is True, bool( ) returns True.
# If a result of an expression is False, bool( ) returns False.
x =5
y = 10
z = 3
j = x < y
k = z > x
print('bool(j) = : ', bool(j))
print('bool(k) = : ', bool(k))
print('-' * 30)