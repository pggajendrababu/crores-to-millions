# note1
# function input( ) takes values only as strings. so in order to convert them to int or float,
#  we have to use  int( ) or float( ).

name = input('Hi, may I know your sweet name : ' ) # note1
age = int(input('your age : '))
number = float(input('tell a real number i.e a number with decimal point : ' ))
print(name, age, number)

