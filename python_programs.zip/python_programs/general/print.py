# To print empty line
print( )
print('') # empty string (pair of single or double quotes)
print('\n')
print('-' *30)

# To print multiline statements
print("""This is first line.
This is second line.
        If you want indentation, leave some space.
""") 