# start the pydroid3
# menu, interpreter
# import math
# dir (math) 
# Then google : math.ceil in python
# math.sqrt(5)

# help ( )
# modules
# math
# press right arrow
# enter key or space key or r or q
