def get_age( ) :
    while True :
        try :
            age = int(input('enter the age : '))
            salary = 30000
            x = salary/age
            return age
        except ZeroDivisionError :
            print('age cannot be zero')    
        except ValueError :
            print('Invalid value')
        
x = get_age( )
print(x)     
    
   