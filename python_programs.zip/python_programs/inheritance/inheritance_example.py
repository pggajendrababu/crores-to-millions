class Sun :
    def add(self, x, y) :
        z = x + y
        return z
        
        
class Earth(Sun) : # Earth inherits Sun.
    pass # empty statement. class cannot be empty. so we 
    # give a empty statement. or else it will produce compile
    # time error.        
    
    
e = Earth( )
print(e.add(5, 7)) #note1
# note1 : since Earth inherits Sun, method add
#  is available to the object e.

class Moon(Earth) : # Moon inherits Earth.
    pass
    
    
m =  Moon( )   
print(m.add(7, 9))
    