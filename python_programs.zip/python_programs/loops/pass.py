count = 0
while True :
    print('count = ', count)
    if count < 4 :
        pass # empty statement (like ; in java) does nothing.
        # if we don't give empty statement, it will produce
        # compile time error (in this situation).
    else :
        break
    count = count + 1                
    