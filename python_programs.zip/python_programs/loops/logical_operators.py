x = 5
y = 2
message1 = 'both values are negative'
message2 = 'one of the value is negative'
message3 = 'both values are positive'
message4 = 'both values are equal to zero'

if x < 0 and y < 0 :
    print(message1)
elif x < 0 or y < 0  :
    print(message2)
elif x > 0 and not y == 0 : 
    print(message3)
else :
    print(message4)
