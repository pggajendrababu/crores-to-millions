x = 5

# If we give single = in note1, then computer will take it as a
# assignment statement. Then, if statement will produce
# error. so whenever we compare two
# things for equality, we should give "==" as in note1.

if x == 6 : # note1
    print('x = ', x)
elif x != 5 : # means if x is not equal to 5
    print('x is not equal to 5')
else :
    print('lotus')
    
if x < -5 :
    print(x)
if x <= 3 :
    print(x)
if x > 10 :
    print('Lion')
if x >= 15 : # if x is greater than or equal to 15
    print('elephant')
