for x in 'Japan' :
    print(x)
print('-' * 30)

for x in range(0, 5, 1) :
    print('x = ', x)
print('-' * 30)


list = [2, 5, 7, 8.668, 18, 'babu', 'gopu']

i = 0
for x in list :
    print('list[', i , '] = ', x)
    i = i + 1