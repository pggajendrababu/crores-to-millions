x = 0
while (x < 5) == True  :  # note1
    print ("x = ",  x)
    x = x + 1
    
print('=' * 30)	
	
"""
Instead of saying like note1, we can simply leave "==True" part, and simply
say like as in note2. both means the same.
"""

x = 0
while x < 5  :  # note2
    print ("x = ",  x)
    x = x + 1
