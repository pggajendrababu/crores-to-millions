count = 0

"""
=> Instead of writing like note1 of while2.py, we can write like note2 of while3.py.
both means the same. 

=> Because the condition that has been stated in 
note2 is always true, The while loop (note2 in while3.py) will always be executed
continuously without an end. That is why we have given a break statement in
note3. The break statement in note3 will break the while loop in note2, when  the condition in note4 becomes true.

=>  If we make note3 as a comment, then the while loop (note2) will be 
executed without an end. This is called an "infinite loop". If your program 
creates an infinite loop, then you have to close the console window using ctrl+c or
restart the computer using ctrl+alt+del (in windows)
"""

while  True :  # note2
    print ('count = ', count)
    if count == 4 : # note4
        print('rose')
        break # note3
    count = count + 1