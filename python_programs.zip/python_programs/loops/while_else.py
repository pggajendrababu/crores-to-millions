import random
computer_guessed_number = random.randint(0, 10)

count = 0
while count < 3 : # note1
    user_number = int(input('enter a number : '))
    count += 1 # count = count + 1
    if user_number == computer_guessed_number :
        print ('you won')
        break # note2
else : # note3
    print ('you failed\n')
print("computer number = ", computer_guessed_number)    

"""
like if loop, while loop can have an optional else part as note3.

In "if else" loop, if the condition in the "if statement" is
False, else part will be executed. If the condition in the 
"if statement" is True, then else part will not be executed.

similarly,
In "while else" loop, when the condition in the "while loop" becomes
False, else part (note3) will be executed. If the break statement
(note2) breaks the while loop (note1), then else part (note3)
of the while loop (note1) will not be executed.
"""              
     
     