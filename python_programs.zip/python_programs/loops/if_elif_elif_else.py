x = 8
if x < 0 :
		print ("x is a negative number")
elif x == 0 :
		print ("x is equal to zero")
else :
		print ("x is a positive number")