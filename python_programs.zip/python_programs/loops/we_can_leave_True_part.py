know_basic_python = True 
know_GUI = False

if know_basic_python == True and know_GUI == True : # note1
    print('you can call yourself a programmer')
else : print('you cannot call yourself a programer')

"""
Instead of saying like in note1, we can leave "== True" part, and simply 
say like as in note2. so both means the same. 
In other words, when you leave "==True" part as in note2,
python will consider it as note1.
"""

if know_basic_python and know_GUI : # note2
    print('you will get a job')
else : print('you will not get a job')



