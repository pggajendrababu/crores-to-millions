x = True
count = 0

while x == True :  # note1
    print ('count = ', count)
    if count == 4 :
        x = False
    count = count + 1