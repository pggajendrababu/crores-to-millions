import foreign.calculator1 as calc

# procedure oriented programming (no class. so no object creation)

number1 = 0
number2 = 0

# note1
# function input takes values only as strings. so in order to convert them to float
# or int, we have to use fuction float or function int.
# we have similar functions int( ), bool( ) to convert  string to int and boolean respectively.

def get_user_input ( ) :
	global number1, number2
	number1 = float (input ("enter first number : ")) # note1
	number2 = float (input ("enter second number : "))

get_user_input ( )
x = calc.add (number1, number2)
print ("addition of (", number1, ",", number2, ") = ", x )
print ("-" * 30)

get_user_input ( )
x = calc.multiply (number1, number2)
print ("multiplication of (", number1, ",", number2, ") = ", x )
print ("-" * 30)