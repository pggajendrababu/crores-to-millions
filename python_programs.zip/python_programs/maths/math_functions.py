import math

class Mathematics :
    def nth_root (self, n, x) :
        y = math.pow(x, (1/n) )
        return y

print ('round(2.9567, 2) = ', round ( 2.9567, 2 ) ) # round upto 2 digits after the decimal point
print ( 'round(2.9567) = ', round ( 2.9567 ) )
print('abs(-50) = ', abs(-50))
print('abs(50) = ', abs(50))
print('-' * 30)

print('math.ceil(2.43) = ', math.ceil(2.43))
print('math.ceil(2.53) = ', math.ceil(2.53))
print('math.floor(2.43) = ', math.floor(2.43))
print('math.floor(2.93) = ', math.floor(2.93))
print('-' * 30)

print ('math.sqrt(6) = ', math.sqrt ( 6 ) )
print ( 'math.pow(4, 3) = ', math.pow ( 4, 3 ) )

z = Mathematics( );  # This line creates new object of the class Mathematics
k = z.nth_root(3, 125)
print ("nth_root(3, 125) = ", k)
print('-' * 30)


