import foreign.calculator6 as calc

def get_user_input ( ) :
	global c
	number1 = float (input ("enter first number : "))
	number2 = float (input ("enter second number : "))
	c = calc.Calculator (number1, number2) # creating an instance (object) c of the class Calculator6

get_user_input ( )
x = c.add( )
print ("addition = ",x)
print ("-" * 30)

get_user_input ( )
x = c.multiply( )
print ("multiplication = ", x)
print ("-" * 30)
