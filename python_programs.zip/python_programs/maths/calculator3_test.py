import foreign.calculator3 as calc

c = calc.Calculator( )  # creating an instance (object) c of class Calculator3

def get_user_input( ) :
	global c
	number1 = float(input("enter first number : "))
	number2 = float(input("enter second number : "))
	c.set_global_value (number1, number2)

get_user_input ( )		
x = c.add( )
print ("addition = ", x)
print("-" * 30)

get_user_input ( )
x = c.multiply( )
print ("multiplication = ", x)
print ("-" * 30)