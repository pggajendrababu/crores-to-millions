number1 = 10_00_00_000
"""
note1 and note2
=> Don't give space anywhere inside curly braces
=> comma after colon indicates that comma is the separator
charactor
=> d is used for integer values. f is used for float numbers.
"""
print(f"{number1:,d}") # note1
print(f"{number1:_d}") 
print("{:,d}".format(number1)) # note2 (aliter to note1)
print("{:_d}".format(number1)) 
print('-' * 30)
#-------------------------------------------------------------
number2 = 43_85_893.382939491

print(f"{number2:,.2f}")
print(f"{number2:_.2f}")
print('{:,.4f}'.format(number2))
print('{:_.4f}'.format(number2))