class Point :
    
    def __init__(self, x, y) :   # constructor . init means : initialize.
        self.x = x
        self.y = y
    
    def move(self) :
        print('move')
        
    def draw(self) :
        print('draw')
        
        
point1 = Point(10, 20 )  

print(point1.x)
print(point1.y)

point1.draw( )
print('-' * 30)
#------------------------------------------------------

point2 = Point(5, 7)

print(point2.x)
print(point2.y)

point2.move( )

