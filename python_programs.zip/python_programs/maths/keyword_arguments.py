# after def block leave 2 empty lines (convention)

def interest(principal, interest, months) :
    total_interest = principal * (interest/100) * (months/12) 
    print('total_interest = ', total_interest)
    
"""----------------------------------------------------------------------------------------------
>> note1
 If we give positional arguments (arguments without parameter 
name), their order is important. They will be supplied in 
the same order to the  parameters of the fuction.
>> note2
 If we give keyword arguments (arguments with their parameter 
name), we can change their order. It will not create any 
problem. but, don't change their order (best practice).	
----------------------------------------------------------------------------------------------"""
interest(100000, 6, 12)     # note1 
interest(months = 12, principal = 200000,  interest = 6) # note2


"""----------------------------------------------------------------------------------------------
>> note3
 If keyword arguments follows positional arguments,
 it is ok. (KAPA is ok)
>> note4
 If positional argument follows  keyword arguments as in 
 note4,  it will produce error ( PAKA is error).	
----------------------------------------------------------------------------------------------"""
interest(200000, interest = 6, months = 12) # note3
#interest(principal = 200000, 6, 12) # note4
