"""
>> for defining names of a class we use "pascal name 
convention". e.g EmailClient

>> for every "def" that has been defined "inside a class", "self""
(special keyword) should be given as the first parameter, even
if that def does not take any argument from outside.

>> we use class to define new data types. class is like
blueprint of an object. Every object is an instance (copy in 
memory) of a class. (object = instance = copy).

>> attributes are like variables that belongs to a particular
***object***. we can define attribute of an object anywhere
in the class.

>> constructor is a fuction that gets called (automatically)
at the time of creating an object

>> "self" refers to the current object. i.e "self" is a reference
to the current object (in memory) 

>> module : module is just a file with some python code.

"""

class Point :
    
    def move(self) :
        print('move')
        
    def draw(self) :
        print('draw')
        
        
point1 = Point( )
point1.x = 10 # attribute of point1
point1.y = 20 # attribute of point1
point1.z = 30  # attribute of point1    

print(point1.x)
print(point1.y)
print(point1.z)

point1.draw( )   
print('-' * 30)
#---------------------------------------------------------------
point2 = Point( )
point2.x = 5 # attribute of point2
point2.y = -3 # attribute of point2
point2.z = 9  # attribute of point2    

print(point2.x)
print(point2.y)
print(point2.z)

point2.draw( )   
print('-' * 30)
#---------------------------------------------------------------