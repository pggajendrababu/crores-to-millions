# numbers (numerical data types), string, list, dictionary, tuple, set are the 6 data types in python.
# In numbers we have 4 data types : integer, float, complex, boolean.

x = 5
print ( '-'  * 30  )  # strings can be given inside pair of single or double quotes in python
print ( "type of x = ", type ( x ) )

y = 6.896
print ( "type of y = ", type ( y ) )

z = 6 + 8j
print ( "type of z = " , type ( z ) )

k = True # for True and False, first letter should be in capital letter.
#  They are special keywords in python.
print ( "type of k = ", type ( k ) )
print ( "k = ",  k  )
print ( "-" *  30  )

