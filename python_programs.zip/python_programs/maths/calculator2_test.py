import foreign.calculator2 as calc

"""Using note1, we create an object from the class Calculator and we give a name "c" to that object. object = instance = copy of a class. This process is called instantiation."""

c = calc.Calculator( ) # note1

number1 = float (input ("enter first number : "))
number2 = float (input ("enter second number : "))
x = c.add (number1, number2)
print ("addition = ", x )
print ("-" * 30)

number1 = float (input ("enter first number : "))
number2 = float (input ("enter second number : "))
x = c.multiply (number1, number2)
print ("multiplication = ", x)
print ("-" * 30)
