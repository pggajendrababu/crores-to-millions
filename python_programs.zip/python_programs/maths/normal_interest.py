# after def block leave 2 empty lines (convention)

def normal_interest(principal, interest, months) :
    total_interest = principal * (interest/100) * (months/12) 
    return total_interest
    
def start( ) :
    amount = normal_interest(166650, 6, 12)
    print('amount = ', amount )
    
    
#start( )    




