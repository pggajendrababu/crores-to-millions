# after def block leave 2 empty lines (convention)

def compound_interest(principal, interest, months) :
    for x in range(1, months+1, 1) :
        #print('months = ', x)
        # note1 (1 month. so (1/12))
        monthly_interest = principal * (interest/100) * (1/12) # note1
        principal = principal + monthly_interest
        #print('principal = ', principal)
        #print('-' * 30)
    return principal
    
    
def start( ) :
    amount = compound_interest(162100, 6, 12)
    print('amount = ', amount)
    
    
#start( )        



