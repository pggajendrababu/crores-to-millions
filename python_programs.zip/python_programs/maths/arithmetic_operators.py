# A variable is like memory location where you store a value (data).
# In python, to declare a variable, you have to assign a value to it. 
# numbers (numerical data types), string, list, dictionary, tuple, set are the 6 data types in python.
# In numbers we have 4 data types : integer, float, complex, boolean. 

x = 7
y = 2

addition = x + y
subtraction = x - y
multiplication = x * y   
division = x / y   
division2 = x//y  # after division it will write an integer value (fractional part will be discarded)
remainder = x % y   
power = x ** y

print ("addition = ",   addition)
print ("subtraction = ",  subtraction)
print ("multiplication = ",  multiplication)
print ("division = ",  division)
print ("division2 = ",  division2)
print ("remainder = ",  remainder)
print ("power = ",  power)


x = x + 3
print('x = ', x)
x += 4 # means x = x +4 (augmented assignment operator)
print('x = ', x)

y *= 2 #    y = y * 2 (augmented assignment operator)
print('y = ', y)





