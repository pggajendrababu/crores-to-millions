# This program will calculate the maximum principal
# we can invest in bank without TDS (Tax Deduction
# at Source) (in India) (normal interest)

# The maximum interest we can get without TDS per one year
maximum_interest = 9999 # for single account (not for joint account)
current_interest = 6 # 6 %

"""
compare this program with normal_interest.py
maximum_principal * (6/100) * (12 months/12) = 9999
=> maximum_principal = 9999 * (100/6)
=> maximum_principal = maximum_interest * (100/current_interest)
"""

def maximum_principal(maximum_interest, current_interest) :
    amount = maximum_interest * (100/current_interest)
    return amount
    
result = maximum_principal(maximum_interest, current_interest)
print('maximum_principal = ', result)