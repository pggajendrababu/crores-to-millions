import random

# method 1
m = random.random()
print("m = ", m)

# method 2
n = random.randint(0,22)
print("n = ", n)

# another example
randomlist = [ ]
for i in range(0,5):
    k = random.randint(1,30)
    randomlist.append(k)
print( "randomlist = ", randomlist )

# method 3
#Generate 5 random numbers between 10 and 30
a = random.sample(range(10, 30), 5)
print("a = ", a)