#import foreign.converters 
import foreign.converters as con
#from foreign.converters import crores_to_millions
#from foreign.converters import crores_to_millions as cm

# note1 will only work after creating a module __init__.py in the
# folder "foreign"

#from foreign import * # note1

"""
if module converters.py is in "folder string", then we cannot import
converters.py from this (maths) folder. python will import another 
module from "ONLY" child folders. python will "NOT" import a
module from parent folders.
"""

#a = foreign.converters.crores_to_millions(5.8)
#print(a)

b = con.crores_to_millions(5.8)
print(b)

#c = crores_to_millions(5.8)
#print(c)

#d = cm(5.8)
#print(d)

#e = converters.crores_to_millions(5.8)
#print(e)