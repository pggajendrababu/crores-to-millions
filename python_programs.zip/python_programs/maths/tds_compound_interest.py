import compound_interest as ci
# This program will calculate the maximum principal
# we can invest in bank without TDS (Tax Deduction
# at Source) (in India) (compound interest)

# The maximum interest we can get without TDS per one year
maximum_interest = 9999 # for single account (not for joint account)
current_interest = 6 # 6 %

starting_principal = 25000
#increment = 5000
increment = 100


while True :
    #print('starting_principal = ', starting_principal)
    result = ci.compound_interest(starting_principal, current_interest, 12)
    interest = result - starting_principal
    #print('interest = ', interest)
    if (interest > maximum_interest) :
        break
    principal_before_incrementing = starting_principal
    #print('principal_before_incrementing = ', principal_before_incrementing)
    starting_principal = starting_principal + increment 
    #print('-' * 30)   
    
            
print('maximum_principal = ', principal_before_incrementing)