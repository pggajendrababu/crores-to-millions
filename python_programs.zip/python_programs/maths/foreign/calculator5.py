# global values, using constructor, without self in note1 and note2
class Calculator :
	
	number1 = 0
	number2 = 0
	
	def __init__(self,  num1, num2) :
		global number1, number2
		number1 = num1 # note1
		number2 = num2 # note2
		
	def add (self) :
		global number1, number2
		result = number1 + number2
		return result
		
	def multiply (self) :
		global number1, number2
		result = number1 * number2
		return result