# no global values (but only attributes), using constructor, with self in note1 and note2
class Calculator :
	
	def __init__(self,  number1, number2) :
		self.number1 = number1 # note1
		self.number2 = number2 # note2
		
	def add (self) :
		result = self.number1 + self.number2
		return result
		
	def multiply (self) :
		result = self.number1 * self.number2
		return result