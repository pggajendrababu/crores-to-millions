"""object oriented programming (In this example, we have created a class. so we are going to create an object from the class. so this is OOP). But In this example we don't have a global variable."""

class Calculator :
	
	def add (self, number1, number2) :
		result = number1 + number2
		return result
		
	def multiply (self, number1, number2) :
		result = number1 * number2
		return result
		
"""-------------------------------------------------------------------------------------------------------------------------------------
=> In python, a def which is defined inside a class should have "self" as the "first parameter" even if that def doesnot take any values from outside. but a def which is defined outside the class will not have "self" as the ''first parameter"

=> Python will only import another module from the current folder or from the child folders. Python  ***DON'T*** import another module from the parent folders (top level folders).

=> keyword "global" and "self" should not be used inside the same def ("self" canbe used as a parameter and "global" can be used inside that def). In other words, parameter name should not be declared as global (since parameter is local to that def).  keyword "global"" should be used in static context and keyword "self" should be used in non static context. "global" means class-name.variable-name. "self" means object-name.variable-name. both will reside in different areas of the memory. so they are different. number1 and number2 cannot refer both static variable and instance variable at the same time. That is what produced that error. for explanation see maths.foreign.calculator4.py and maths.foreign.calculator3.py.  To understand difference between class, object, this (self) see maths.Circle.java and java-pictures.Circle.jpg
----------------------------------------------------------------------------------------------------------------------------------------"""