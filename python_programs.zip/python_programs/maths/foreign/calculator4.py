# global value, "getter, setter" method, with "self" in note1 and note2

class Calculator  :
		
		# no underscore = public
		# single underscore = protected
		# double underscore = private
		
	__number1 = 0  # private
	__number2 = 0 # private
	
	
	"""-------------------------------------------------------------------------------------------------------------------------------------
		If we uncomment note1, it will produce "number1 is both parameter and global" error.
		
		keyword "global" and "self" should not be used inside the same def ("self" canbe used as a parameter and "global" can be used inside that def). In other words, parameter name should not be declared as global (since parameter is local to that def).  keyword "global"" should be used in static context and keyword "self" should be used in non static context. "global" means class-name.variable-name. "self" means object-name.variable-name. both will reside in different areas of the memory. so they are different. number1 and number2 cannot refer both static variable and instance variable at the same time. That is what produced that error.  To understand difference between class, object, this (self) see maths.Circle.java and java-pictures.Circle.jpg
    -------------------------------------------------------------------------------------------------------------------------------------"""
	
	def set_global_value (self, number1, number2) :
		#global number1, number2  # note1
		self.number1 = number1 # note1
		self.number2 = number2 # note2
	
	def add (self) :
		result = self.number1 + self.number2
		return result
		
	def multiply (self) :
		result = self.number1 * self.number2
		return result