def find_max(list) :
    maximum = list[0] # max is an in-built function in python.
    # so we should not use "max" as a variable name. so we
    # can use "maximum" as a variable name.
    for item in list :
        if item > maximum :
            maximum = item
    return maximum
    
def remove_duplicates(list) :
    no_duplicates = [ ]
    for item in list :
        if  item not in no_duplicates : 
            no_duplicates.append(item)
    return no_duplicates
    
#print(remove_duplicates([2,3,3,4,5]))
#print(find_max([2, 6, 7, 4, 9, 14, 3, 7]))        