# procedure oriented programming (no class. so no object creation)

def add (number1, number2) :
		result =	number1 + number2
		return result
def multiply (number1, number2) :
		result =	number1 * number2
		return result
	