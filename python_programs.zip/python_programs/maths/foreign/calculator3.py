# global value, "getter, setter" method, without "self" in note1 and note2

class Calculator  :
		
		# no underscore = public
		# single underscore = protected
		# double underscore = private
		
	__number1 = 0  # private
	__number2 = 0 # private
	
	def set_global_value (self, num1, num2) :
		global number1, number2
		number1 = num1 # note1
		number2 = num2 # note2
	
	def add (self) :
		global number1, number2
		result = number1 + number2
		return result
		
	def multiply (self) :
		global number1, number2
		result = number1 * number2
		return result