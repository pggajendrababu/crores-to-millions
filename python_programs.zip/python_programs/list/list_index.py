numbers = [5, 10, 7, 8, 15, 3, 9]
print(f"numbers[1] = {numbers[1]}")
print('-' * 30)

# we can change the elements in the list
numbers[3] = 60

for x in numbers :
    print(x)
print('-' * 30)    

# like in strings, we can do slicing operations in a list
print(numbers)
print("numbers[1:4] = ", numbers[1:4]) # excluding 4th element
print("numbers[-3 : -1] = ", numbers[-3 : -1]) # -1 is the final element
print("numbers[2 : ] = ", numbers[2 : ]) # means numbers[2 : n]
print("numbers[ : 4] = ", numbers[ : 4]) # means numbers [0 : 4]