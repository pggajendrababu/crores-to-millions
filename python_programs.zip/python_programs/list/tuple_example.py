numbers = (3, 7, 9, 8, 8) # tuple

print(numbers[1]) # note : Here, for tuple also, 
# we use square brackets.

# tuples are immutable (we cannot modify them). so 
# trying to change an element of a tuple will produce 
# an errror (note1).

#numbers[1] = 10  # note1

print(numbers.index(8))
print(numbers.count(8))
# other than the above two methods, there are no methods
# regarding tuple.
print('-' * 30)
#--------------------------------------------------------------------------------------
# but we can unpack  a tuple.
a, b, c, d, e = numbers

""" 
The  above code means :
    a = numbers[0]
    b = numbers[1]
    c = numbers[2]
    d = numbers[3]
    e = numbers[4]
    This is called unpacking. ***Unpacking can be done on list also.*** 
    unpacking is done to increase the readability of the code.
    Instead of saying like
    k = numbers[0] * numbers[1],
    we can now simply say k = a * b
"""
print(a)
print(b)
#--------------------------------------------------------------------------------------
    