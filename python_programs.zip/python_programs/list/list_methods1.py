list = [4, 8, 6, 13, 45, 7, 4, 6, 9]

print(list)
list.append(15) # at the end
list.insert(2, 17) # at the specific index
print('after appending 15 and inserting 17 at index 2')
print(list)
print('-' * 30)
#----------------------------------------------------------------------------------------------
list.pop( ) # will remove the last element
list.remove(13)
print('after pop( ) and removing 13')
print(list)
print('-' * 30)
#----------------------------------------------------------------------------------------------
print('8 in list = ', 8 in list)
print('list.index(8) = ', list.index(8))
print('list.count(4) = ', list.count(4))
print('-' * 30)
#----------------------------------------------------------------------------------------------
# "None" in python  is an object that represent the absence 
# of a value. list.sort( ) method returns no value. It just 
# sorts the element of list. so note1 will prodce "None" as
# the result.

print(list.sort( )) # note1
list.sort( )
print(list)
list.reverse( )
print(list)
print('-' * 30)
#----------------------------------------------------------------------------------------------
china = list.copy( )
list.clear( )
print('after list.copy( ) and list.clear( )')
print("list = ", list)
print("china = ", china)
#----------------------------------------------------------------------------------------------