matrix = [ 
    [3, 7, 8],
    [15, 4, 60],
    [25, -1, 12]
]
matrix [1] [2] = 22 # we can change an element
print(matrix[1] [2])
print(matrix)
print('-' * 30)

for row in matrix :
    for item in row :
        print(item)

             