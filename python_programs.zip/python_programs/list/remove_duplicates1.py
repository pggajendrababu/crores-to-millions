list = [4, 5, 6, 12, 8, 34, 4, 7, 8, 4]
no_duplicates = [ ]
for item in list :
    if  (item in no_duplicates) == False :
        no_duplicates.append(item)
print(list)        
print(no_duplicates)        