list = [1, 5, 3, 30, 17, 25, 7]
max = list[0]
for item in list :
    if item > max :
        max = item
print(f"maximum = {max}")        