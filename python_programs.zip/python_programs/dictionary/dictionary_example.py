dict = {
    "name" : "Rahul",
    "age" : 18,
    "married" : True,
    1 : 500,
    2 : 30
}

# dectionary keys should be unique. otherwise it will 
# produce error.

print(dict["name"])
print(dict[2])
print(dict)
dict ["door number"]  = 15 # like assignment statement
print(dict)
print('-' * 30)

#  Another way to retrieve a value from a dictionary is get method.
# If a key does not exist , it will produce KeyError.
# but if we use get method, and if the key does not exist, then
# it will just return "None". Another advantage of get method
# is, even we can supply  a value to a non existing key.

#print(dict["email"]) # This line will produce KeyError.

print(dict.get("email"))
print(dict.get("email", "rahul@gmail.com")) # note1
# note1 will ***NOT*** store a "key, value pair" in the dictionary.
# note1 will only supply a value to the non existing key "email".
print(dict)
del dict["age"]
print( )
print('after removing age')
print(dict)
print('-' * 30)